export interface TweetComment{
  comment:string;
}
