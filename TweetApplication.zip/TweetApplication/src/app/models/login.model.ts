export interface Login{
  loginId:string;
  password:string;
}
