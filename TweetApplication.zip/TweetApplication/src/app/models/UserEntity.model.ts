export interface UserEntity{
  firstName:string,
  lastName:string,
  email:string,
  loginId:string,
  password:string,
  confirmPassword:string,
  contactNumber:string
}
