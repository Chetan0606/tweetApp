export interface UserDetailsResponse{
    firstName:string,
    lastName:string,
    email:string,
    loginId:string,
    contactNumber:string
  }