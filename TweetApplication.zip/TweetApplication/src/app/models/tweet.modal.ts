export interface TweetResponse{
  tweetId:number;
  tweet:string;
  tweetPostTime:string;
  userName:string;
  tag:string;
}
