export interface commentResponse{
  id:number;
  comment:string;
  userName:string;
}
