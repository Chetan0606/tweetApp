import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { commentResponse } from '../models/CommentResponse.modal';
import { TweetComment } from '../models/TweetComment.modal';

@Injectable({
  providedIn: 'root'
})
export class TweetActionService {

  constructor(private http:HttpClient) { }

  getLikes(userName:string,tweetId:number):Observable<number>{
    return this.http.post<number>(`http://localhost:9347/api/v1.0/tweets/${userName}/likes/${tweetId}`,{},{responseType: 'number' as 'json'});
  }

  getNumberOfLikes(tweetId:number):Observable<number>{
    return this.http.get<number>(`http://localhost:9347/api/v1.0/tweets/likes/${tweetId}`)
  }

  getComments(userName:string,tweetId:number,comment:TweetComment):Observable<TweetComment>{
    return this.http.post<TweetComment>(`http://localhost:9347/api/v1.0/tweets/${userName}/comment/${tweetId}`,comment);
  }
  getCommentByTweetId(tweetId:number):Observable<commentResponse[]>{
    return this.http.get<commentResponse[]>(`http://localhost:9347/api/v1.0/tweets/comment/${tweetId}`).pipe(
      map((data)=>data?.reverse())
    );
  }
}
