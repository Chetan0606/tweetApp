import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, map, Observable, tap } from 'rxjs';
import { Login } from '../models/login.model';
import { UserDetailsResponse } from '../models/UserDetailsResponse.model';
import { UserEntity } from '../models/UserEntity.model';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  loginIds: string[] = [];
  isLogin = new BehaviorSubject<boolean>(false);
  constructor(private http: HttpClient) { }

  userLogin(loginDetails: Login): Observable<string> {
    return this.http.post<string>('http://localhost:9959/api/v1.0/tweets/login', loginDetails,{responseType:'string' as 'json'});
  }
  getAllUser():Observable<String[]> {
    console.log('inside service getAllUser')
    return this.http.get<string[]>('http://localhost:9959/api/v1.0/tweets/users').pipe(
      map((value)=>{
        this.loginIds=value;
        console.log(this.loginIds,'inside map')
        return this.loginIds
      })
    );
  }
  registerNewUser(userEntity:UserEntity){
    return this.http.post<string>('http://localhost:9959/api/v1.0/tweets/register',userEntity,{responseType:'string' as 'json'} );
  }

  getAllDetailsOfUser(userName: string):Observable<UserDetailsResponse>{
    return this.http.get<UserDetailsResponse>(`http://localhost:9959/api/v1.0/tweets/userDetails/${userName}`);
  }

  get loginSubject(){
    return this.isLogin.asObservable();
  }

  isLoginClicked(){
    let userName = sessionStorage.getItem('userId');
    if(userName){
      this.isLogin.next(true);
    }
  }

  isLogoutClicked(){
    let userName = sessionStorage.getItem('userId');
    if(!userName){
      this.isLogin.next(false);
    }
  }

  forgotPassword(forgotPassword:any){
    return this.http.post<string>(`http://localhost:9959/api/v1.0/tweets/forgot/${forgotPassword.loginId}`,forgotPassword,{responseType:'string' as 'json'});
  }


}
